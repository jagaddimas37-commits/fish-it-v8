extends Control

func _ready():
	$VBoxContainer/HostButton.pressed.connect(_on_host_pressed)
	$VBoxContainer/JoinButton.pressed.connect(_on_join_pressed)
	$VBoxContainer/QuitButton.pressed.connect(_on_quit_pressed)

func _on_host_pressed():
	var peer = ENetMultiplayerPeer.new()
	peer.create_server(Game.PORT, 32)
	multiplayer.multiplayer_peer = peer
	get_tree().change_scene_to_file("res://World.tscn")

func _on_join_pressed():
	var ip = $VBoxContainer/IP.text
	if ip == "": ip = "127.0.0.1"
	var peer = ENetMultiplayerPeer.new()
	peer.create_client(ip, Game.PORT)
	multiplayer.multiplayer_peer = peer
	get_tree().change_scene_to_file("res://World.tscn")

func _on_quit_pressed():
	get_tree().quit()