extends Control

func _ready():
	var judul = Label.new()
	judul.text = "FISH IT ULTIMATE V6"
	judul.add_theme_color_override("font_color", Color(0.7, 0, 1))
	judul.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	judul.position = Vector2(640, 900)
	judul.scale = Vector2(3, 3)
	add_child(judul)
	
	var credit = Label.new()
	credit.text = "dibuat oleh satria studio"
	credit.add_theme_color_override("font_color", Color(0.9, 0.7, 1))
	credit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER  
	credit.position = Vector2(640, 1020)
	credit.scale = Vector2(2, 2)
	add_child(credit)
	
	var glow = Label.new()
	glow.text = "FISH IT ULTIMATE V6"
	glow.modulate = Color(0.7, 0, 1, 0.3)
	glow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	glow.position = Vector2(640, 900)
	glow.scale = Vector2(3.2, 3.2)
	add_child(glow)
	move_child(glow, 0)

# BERAT VERSI LU
var fish_weight_min = [6.0, 1.0, 25.0, 30.0, 35.0, 200.0, 1000.0, 1000.0, 1000.0] # kg
var fish_weight_max = [20.0, 5.0, 30.0, 35.0, 150.0, 900.0, 100000.0, 100000.0, 100000.0] # kg
var fish_weight_data = {}

func _ready():
	generate_2000_fish()
	setup_all_boats()
	setup_all_rods()
	setup_all_bobbers()
	setup_gempas_shop()
	setup_shopkeeper()
	print("SERVER READY - 2000 ITEM + 2010 IKAN LOADED")

func generate_2000_fish():
	var rarity_names = ["Normal","Uncommon","Rare","Epic","Legendary","Mythic","Galaxy","Void","Absolute God"]
	var rarity_count = [1200, 400, 200, 100, 50, 30, 15, 4, 1]
	
	var ikan_asli = [
		"Lele","Gurame","Gabus","Toman","Nila","Mujair","Patin","Bawal","Mas","Koi",
		"Arwana","Louhan","Cupang","Guppy","Molly","Platy","Manfish","Discus","Oscar","Lemon",
		"Belida","Jelawat","Tawes","Sepat","Betok","Tambakan","Kakap","Kerapu","Baronang",
		"Tuna","Tongkol","Cakalang","Tenggiri","Salmon","Trout","Bass","Cod","Hiu","Pari",
		"Belut","Sidat","Wader","Betutu","Bandeng","Belanak","Sembilang","Manyung","Baung",
		"Arapaima","Megalodon","Piranha","Sapu Sapu","Gatul","Lundu","Botia","Juaro","Seluang",
		"Channa Andrao","Channa Barca","Channa Maru","Channa Auranti","Channa Bleheri","Channa Pulchra"
	]
	
	var gelar = ["Raja","Emperor","King","Mega","Giga","Ultra","Super","Golden","Diamond","Ancient","Mystic","Void","Cosmic","Galaxy","Demon","Angel","God","Titan","Chaos"]
	
	for r in range(9):
		var rarity = rarity_names[r]
		fish_names[rarity] = []
		for i in range(rarity_count[r]):
			var name = ""
			if r == 8:
				name = "SATRIA GOD " + ikan_asli[randi() % ikan_asli.size()] + " " + str(i+1)
			elif r >= 6:
				name = gelar[randi() % gelar.size()] + " " + ikan_asli[randi() % ikan_asli.size()] + " " + str(i+1)
			else:
				name = ikan_asli[randi() % ikan_asli.size()] + " " + str(i+1)
			
			fish_names[rarity].append(name)
			var min_w = fish_weight_min[r]
			var max_w = fish_weight_max[r]
			var berat = snapped(randf_range(min_w, max_w), 0.1)
			fish_weight_data[name] = berat
	
	# TAMBAH IKAN SPESIAL REQUEST LU
	var special_fish = ["Megalodon", "Arapaima Gigas", "Toman Chana", "Ikan Mitos Naga", "Leviathan"]
	for special in special_fish:
		var nama_god = "SATRIA GOD " + special
		fish_names["Absolute God"].append(nama_god)
		var berat_god = snapped(randf_range(50000.0, 100000.0), 0.1) # 50-100 ton
		fish_weight_data[nama_god] = berat_god

	var special_mythic = ["Megalodon Muda", "Arapaima Emas", "Toman Chana Albino", "Channa Maru", "Channa Barca"]
	for special in special_mythic:
		var nama_mythic = "Ancient " + special
		fish_names["Mythic"].append(nama_mythic)
		var berat_mythic = snapped(randf_range(500.0, 900.0), 0.1)
		fish_weight_data[nama_mythic] = berat_mythic
	
	print("BERHASIL GENERATE 2010 IKAN + BERAT")

func setup_all_boats():
	boats.clear()
	for i in range(2000):
		boats[i] = {"name":"Boat " + str(i), "speed":100+i*5, "luck":1+i, "cost":0, "owner_only":false}
	boats[2000] = {"name":"KapalSatriaSkibidi","speed":99999,"luck":9999,"cost":0,"owner_only":false}

func setup_all_rods():
	rods.clear()
	for i in range(2000):
		rods[i] = {"name":"Rod " + str(i), "luck":1+i*10, "cost":0, "owner_only":false}
	rods[2000] = {"name":"KATANA AQUAFISHER","luck":999999,"cost":0,"owner_only":false,"effect":"HEPTADRA_SLASH"}

func setup_all_bobbers():
	bobbers.clear()
	for i in range(2000):
		bobbers[i] = {"name":"Bobber " + str(i),"luck":2+i,"mutasi":"Normal","cost":0}
	bobbers[2000] = {"name":"プランプン","luck":999999,"mutasi":"BLACK HOLE","cost":0,"owner_only":false}

func setup_gempas_shop():
	gempas.clear()
	for i in range(1000):
		gempas[i] = {"name":"Gempas " + str(i), "power":10+i*5, "cost":0}
	gempas[1000] = {"name":"GEMPAS SATRIA DEWA","power":999999,"cost":0,"owner_only":false}

func setup_shopkeeper():
	pass # NPC Shop kalo ada