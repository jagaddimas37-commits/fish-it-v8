extends CharacterBody3D
var coins = 999999999
var diamonds = 999999999
var boat_id = 129999999999
var rod_id = 99999999
var bobber_id = 999999999999
var pet_id = 139999999
var owned_gempas = [true]
var achievements_progress = {}
var total_fish = 0
var is_fishing = false
var is_vip = true
var vip_expire = 99999999999
var afk_enabled = true
var afk_income = 0
var afk_time = 0.0
var owner_aura_time = 0.0

func _ready():
	add_to_group("players")
	if Game.is_owner(name.to_int()):
		spawn_owner_aura()
		give_permanent_vip()

func _physics_process(delta):
	if afk_enabled:
		afk_time += delta
		if afk_time >= 0.1:
			afk_time = 0
			var income = 99999 * Game.get_money_multiplier(name.to_int())
			coins += income
			afk_income += income
			auto_fish()
			Game.update_leaderboard(name.to_int(), coins, total_fish)
	
	if Game.is_owner(name.to_int()):
		owner_aura_time += delta
		if owner_aura_time >= 5.0:
			owner_aura_time = 0
			spawn_owner_aura()

func auto_fish():
	if not is_fishing: return
	var total_luck = rods[rod_id].luck + bobbers[bobber_id].luck + boats[boat_id].luck
	
	# Makin gede total_luck = makin gampang dapet ikan langka
	var rarity_roll = randf() * 10000 / total_luck
	
	if rarity_roll < 0.1: rarity = "Absolute God"
	elif rarity_roll < 1: rarity = "Secret" 
	elif rarity_roll < 10: rarity = "Void"
	elif rarity_roll < 100: rarity = "Galaxy"
	# dst...to_int(), 0)
	var rarity_index = Game.weighted_random(Game.fish_weights)
	var fish_name = Game.fish_names[Game.fish_rarities[rarity_index]].pick_random()
	var value = Game.fish_values[rarity_index] * Game.get_money_multiplier(name.to_int())
	coins += value
	total_fish += 1
	add_achievement_progress(0, 1)
	if rarity_index >= 3: add_achievement_progress(3, 1)
	if rarity_index == 8: add_achievement_progress(5, 1)
	Game.play_sfx("splash", global_position)
	if rarity_index >= 3: Game.play_sfx("legendary")
	if rarity_index >= 6: Game.play_sfx("dragon")
	if Game.boss_active: Game.damage_boss(name.to_int(), 10000)
	is_fishing = false

func give_permanent_vip():
	is_vip = true
	vip_expire = 99999999999
	coins = 999999999
	diamonds = 999999999

func spawn_owner_aura():
	Game.play_sfx("heptadra", global_position)
	if ResourceLoader.exists("res://vfx/heptadra.tscn"):
		var aura = load("res://vfx/heptadra.tscn").instantiate()
		get_tree().current_scene.add_child(aura)
		aura.global_position = global_position + Vector3(0,3,0)

func add_achievement_progress(id: int, amount: int):
	if not id in achievements_progress: achievements_progress[id] = 0
	achievements_progress[id] += amount
	if achievements_progress[id] >= Game.achievements[id]["goal"]:
		coins += Game.achievements[id]["reward_coin"] if "reward_coin" in Game.achievements[id] else 0
		diamonds += Game.achievements[id]["reward_diamond"] if "reward_diamond" in Game.achievements[id] else 0